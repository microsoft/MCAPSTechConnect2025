from typing import Generator, Tuple
from askai_core.content_parser import BaseParser
from docx import Document
import io

class DocxParser(BaseParser):
    
    def extract_text(self) -> Generator[Tuple[int, str, bool], None, None]:
        is_image_present = False
        content_bytes = self.file_content
        document = Document(io.BytesIO(initial_bytes= content_bytes))
        page_number=1
        page_content = ""
        # Iterate through paragraphs
        for i, paragraph  in enumerate(document.paragraphs):
            
            page_content = page_content+paragraph.text
            if (paragraph.contains_page_break or page_number==1):
                                
                yield page_number, page_content.strip(), is_image_present 
                page_number += 1
                page_content=""
            
    def extract_table(self) -> Generator[Tuple[int, str], None, None]:
        content_bytes = self.file_content
        document = Document(io.BytesIO(initial_bytes= content_bytes))
        table_number=1
        table_content = ""
        # Iterate through tables
        for table in iter_tables(document):
            df = [['' for i in range(len(table.columns))] for j in range(len(table.rows))]
            for i, row in enumerate(table.rows):
                for j, cell in enumerate(row.cells):
                    if cell.text:
                        df[i][j] = cell.text.replace('\n', '')
            table_content = f'table {table_number}:\n{df}\n'
            yield table_number, table_content.strip()
            table_number += 1
            table_content=""       
    
    def extract_images(self) -> Generator[Tuple[int, bytes], None, None]:
        content_bytes = self.file_content
        document = Document(io.BytesIO(initial_bytes= content_bytes))
        image_content = ""
        # Iterate through images
        for para in document.paragraphs:
            for run in para.runs:
                for inline in run._r.xpath("w:drawing/wp:inline"):
                    
                    rId = inline.graphic.graphicData.pic.blipFill.blip.embed
                    image = document.part.related_parts[rId].image
                    filename = image.filename
                    image_content = image.blob
                    yield filename, image_content
        

def iter_tables(block_item_container):
        for t in block_item_container.tables:
            yield t
            for row in t.rows:
                for cell in row.cells:
                    yield from iter_tables(cell)