from io import BytesIO
from openpyxl import load_workbook
from openpyxl.cell.cell import MergedCell
from openpyxl.utils import get_column_letter
from askai_core.content_parser.base_parser import BaseParser

class ExcelParser(BaseParser):
    def is_image_in_cell(self, cell, worksheet):
        """Check if the cell contains an image."""
        for image in worksheet._images:
            if hasattr(image.anchor, 'to'):  # twoCellAnchor
                start_col = image.anchor._from.col
                start_row = image.anchor._from.row
                end_col = image.anchor.to.col
                end_row = image.anchor.to.row
            elif hasattr(image.anchor, 'col'):  # oneCellAnchor
                start_col = end_col = image.anchor.col
                start_row = end_row = image.anchor.row
            else:  # absoluteAnchor or unknown
                continue  # Skip this image if we can't determine its position

            if (start_col <= cell.column - 1 <= end_col) and (start_row <= cell.row - 1 <= end_row):
                try:
                    return image._data()
                except ValueError:
                    return None
        return None
    
    def get_cell_info(self, cell):
        """Get cell info handling both regular and merged cells."""
        cell_row_address = cell.row if cell.row is not None else None
        
        if isinstance(cell, MergedCell):
            cell_column_address = get_column_letter(cell.column)
        else:
            cell_column_address = cell.column_letter if cell.column_letter is not None else None

        return cell_row_address, cell_column_address

    def extract_text(self, chunk_size=1000):
        excel_bytes = self.file_content
        
        # Load the Excel file from the bytes
        excel_file = BytesIO(excel_bytes)
        
        """Generator to read Excel file efficiently, yielding row, column address, and cell data with image detection."""
        # Load the workbook in read-only mode for large files
        workbook = load_workbook(filename=excel_file, read_only=False, data_only=False)

        for sheet in workbook.sheetnames:
            worksheet = workbook[sheet]
        
            for row in worksheet.iter_rows():
                for cell in row:
                    # Check if the cell contains an image
                    image_bytes = self.is_image_in_cell(cell, worksheet)
                    
                    # Check if the cell is empty (it might be an EmptyCell object)
                    if (cell is None or cell.value is None) and image_bytes is None:
                        continue  # Skip empty cells
                    
                    # Handle empty cells
                    if cell.value is None:
                        cell_value = None
                    else:
                        cell_value = cell.value

                    cell_row_address, cell_column_address = self.get_cell_info(cell)

                    # Yield the result as a tuple of 5 values
                    yield (sheet, cell_value, cell_row_address, cell_column_address, image_bytes)
                    