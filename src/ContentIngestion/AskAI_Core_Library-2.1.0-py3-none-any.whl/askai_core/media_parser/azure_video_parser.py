from askai_core.media_parser.base_parser import BaseParser
from askai_core.Utility.functions import async_get,count_tokens_str,get_arm_access_token,get_account_access_token_async,extract_account_url,get_account_async
import logging
import json
import os
import hashlib


class AzureVideoParser(BaseParser):
    def __init__(self, token_size:int,auth_url: str, auth_params:dict, client_id:str, client_secret:str, tenant_id:str, file_ext: str, file_video_id: str = None):
        super().__init__(token_size,auth_url,auth_params,client_id,client_secret,tenant_id,file_ext,file_video_id)
        self.arm_access_token = get_arm_access_token(self.tenant_id,self.client_id,self.client_secret)
        self.vi_access_token = get_account_access_token_async(self.auth_url, self.auth_params, self.arm_access_token,file_video_id)
        self.account = None
        self.api_endpoint="https://api.videoindexer.ai"
        self.azure_resource_manager="https://management.azure.com"

    def get_object_size(self,obj):
        json_str = json.dumps(obj)
        return len(json_str.encode('utf-8'))
        megabytes_size = bytes_size / (1024 * 1024)  # Convert bytes to megabytes
        return megabytes_size    
        
    async def extract_transcript(self):
        insights=await self.get_video_index_insights_async(self.file_video_id,self.auth_url)
        results = []
        if insights and insights.get('videos'):
            video_insights = insights.get('videos')[0]
            transcript = video_insights.get('insights').get('transcript', [])
            current_chunk_text = ""
            current_chunk_token_count = 0
            start_date = None  # Initialize start date of the first chunk
            end_date = None    # Initialize end date of the last chunk
            segment_id = 1   
            for i,entry in enumerate(transcript):
                transcript_text = entry.get('text')
                current_start_date = entry.get('instances', [])[0].get('start')
                current_end_date = entry.get('instances', [])[0].get('end')
                text_with_timestamp = f"{{{current_start_date} - {current_end_date}}} {transcript_text}"
                
                # Calculate the token count for the text_with_timestamp
                token_count = count_tokens_str(text_with_timestamp)
                if i == 0:
                    start_date = current_start_date
                # If adding the current text exceeds the chunk size, start a new chunk
                if current_chunk_token_count + token_count > self.token_size:
                    yield {'segmentid': segment_id, 'text': current_chunk_text, 'startdate': start_date, 'enddate': end_date}
                    current_chunk_text = text_with_timestamp
                    current_chunk_token_count = token_count
                    start_date = current_start_date  # Update start date for the next chunk
                    segment_id += 1 
                else:
                    current_chunk_text += text_with_timestamp
                    current_chunk_token_count += token_count
                    
                end_date = current_end_date  # Update end date for the last chunk
                
            # Add the last chunk
            if current_chunk_text:
                yield {'segmentid': segment_id, 'text': current_chunk_text, 'startdate': start_date, 'enddate': end_date}
        else:
            yield []  # Yield an empty list if there are no insights
        
    async def extract_keywords(self):
        insights=await self.get_video_index_insights_async(self.file_video_id,self.auth_url)
        if insights and insights.get('videos'):
            video_insights = insights.get('videos')[0]
            keywords = video_insights.get('insights').get('keywords', [])
            return keywords
        else:
            return []
    async def extract_namedPeople(self):
        insights=await self.get_video_index_insights_async(self.file_video_id,self.auth_url)
        if insights and insights.get('videos'):
            video_insights = insights.get('videos')[0]
            namedPeople= video_insights.get('insights').get('namedPeople', [])
            return namedPeople
        else:
            return []
    async def get_video_index_insights_async(self, video_id: str,auth_url:str) -> dict:
        
        account_url = extract_account_url(auth_url)
        if self.account is None:
            self.account = get_account_async(account_url,self.arm_access_token)
        
        url = f'{self.api_endpoint}/{self.account["location"]}/Accounts/{self.account["properties"]["accountId"]}/Videos/{video_id}/Index'
        params = {
            'accessToken': self.vi_access_token,
            'language': 'English',  # Assuming language is always English
            'format': 'Jpeg'  # Assuming the format is always Jpeg
        }
        try:
            insights = await async_get(url, params)
            return insights
        except Exception as ex:
            logging.info(f"Could not get video index insights for video ID {video_id}. Error: {ex}")
            return None
    
