import os
import time
from urllib.parse import urlparse
import requests
import logging

from askai_core.Utility.functions import get_arm_access_token,async_get,get_account_access_token_async,extract_account_url,get_account_async,post_request

class AzureVideoIndexer:
    def __init__(self, auth_url: str,auth_params:dict, client_id:str, client_secret:str, tenant_id:str, blob_url_with_sas: str, file_path: str = None,file_name:str=None):
        self.file_path = file_path
        self.blob_url_with_sas = blob_url_with_sas
        self.file_name = file_name
        self.client_id = client_id
        self.auth_url = auth_url
        self.auth_params = auth_params
        self.client_secret = client_secret
        self.tenant_id = tenant_id
        self.account = None
        self.arm_access_token = get_arm_access_token(self.tenant_id,self.client_id,self.client_secret)
        self.vi_access_token = get_account_access_token_async(self.auth_url, self.auth_params, self.arm_access_token,None)
        self.api_endpoint="https://api.videoindexer.ai"
        self.azure_resource_manager="https://management.azure.com"
    
    async def upload_url_async(self,auth_url:str, video_name:str, video_url:str, excluded_ai:list[str],
                         wait_for_index:bool, video_description:str='', privacy='private') -> str:
        # check that video_url is valid
        parsed_url = urlparse(video_url)
        if not parsed_url.scheme or not parsed_url.netloc:
            raise Exception(f'Invalid video URL: {video_url}')

        account_url = extract_account_url(auth_url)
        if self.account is None:
            self.account = get_account_async(account_url,self.arm_access_token) # If account is not initialized, get it

        url = f'{self.api_endpoint}/{self.account["location"]}/Accounts/{self.account["properties"]["accountId"]}/' + \
               'Videos'
        
        params = {
            'accessToken': self.vi_access_token,
            'name': video_name,
            'description': video_description,
            'privacy': privacy,
            'videoUrl': video_url
        }

        if len(excluded_ai) > 0:
            params['excludedAI'] = ','.join(excluded_ai)

        response = await post_request(url, params)
        video_id = response.get('id')
        logging.info(f'Video ID {video_id} was uploaded successfully')

        if wait_for_index:
            await self.wait_for_index_async(video_id)

        return video_id
    
    async def file_upload_async(self,media_path:str, video_name:str, excluded_ai:list[str],
                          video_description:str='', privacy='private', partition='') -> str:
        
        if not os.path.exists(media_path):
            raise Exception(f'Could not find the local file {media_path}')

        account_url = extract_account_url(self.auth_url)
        if self.account is None:
            self.account = get_account_async(account_url,self.arm_access_token) # If account is not initialized, get it


        url = f'{self.api_endpoint}/{self.account["location"]}/Accounts/{self.account["properties"]["accountId"]}/' + \
               'Videos'

        params = {
            'accessToken': self.vi_access_token,
            'name': video_name,
            'description': video_description,
            'privacy': privacy,
            'partition': partition
        }

        if len(excluded_ai) > 0:
            params['excludedAI'] = ','.join(excluded_ai) 

        logging.info('Uploading a local file using multipart/form-data post request..')

        response = requests.post(url, params=params, files={'file': open(media_path,'rb')})
        response.raise_for_status()

        if response.status_code != 200:
            logging.info(f'Request failed with status code: {response.StatusCode}')

        video_id = response.json().get('id')
        
        return video_id
        
    async def wait_for_index_async(self, video_id:str, language:str='English') -> None:
        
        account_url = extract_account_url(self.auth_url)
        if self.account is None:
            self.account = get_account_async(account_url,self.arm_access_token) # If account is not initialized, get it

        processing = True
        logging.info(f'Waiting for video {video_id} to finish indexing.')

        while processing:
            url = f'{self.api_endpoint}/{self.account["location"]}/Accounts/{self.account["properties"]["accountId"]}/' + \
                  f'Videos/{video_id}/Index'

            params = { 
                'accessToken': self.vi_access_token,
                'language': language
            }

            response = await async_get(url, params)
            video_state = response.get('state')

            if video_state == 'Processed':
                processing = False
                logging.info(f'The video index has completed. Here is the full JSON of the index for video ID {video_id}: \n{response}')
                return
            elif video_state == 'Failed':
                processing = False
                logging.info(f"The video index failed for video ID {video_id}.")
                return
            
            logging.info(f'The video index state is {video_state}')
            time.sleep(10) # wait 10 seconds before checking again
    
    async def get_index_status_async(self, video_id:str, language:str='English') -> str:
        
        account_url = extract_account_url(self.auth_url)
        if self.account is None:
            self.account = get_account_async(account_url,self.arm_access_token) # If account is not initialized, get it

        processing = True
        logging.info(f'Waiting for video {video_id} to finish indexing.')

        
        url = f'{self.api_endpoint}/{self.account["location"]}/Accounts/{self.account["properties"]["accountId"]}/' + \
                f'Videos/{video_id}/Index'

        params = { 
            'accessToken': self.vi_access_token,
            'language': language
        }

        response = await async_get(url, params)
        video_state = response.get('state')
        logging.info(f'The video index state is {video_state}')
        return video_state

    async def upload_index_localfile(self,wait_for_index:bool=True):
        excludedAI = []
        file_video_id = await self.file_upload_async(self.file_path,self.file_name,excludedAI)
        if wait_for_index:
            await self.wait_for_index_async(file_video_id)
        
        return file_video_id
    
    async def upload_index_blobfile(self,wait_for_index:bool=True):
        excludedAI = []
        video_id = await self.upload_url_async(self.auth_url,self.file_name,self.blob_url_with_sas,excludedAI, wait_for_index)
        return video_id
        