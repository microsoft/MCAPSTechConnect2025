from enum import Enum
import logging
from azure.identity import DefaultAzureCredential
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from askai_core.common.openai_utils import OpenAIUtility
from askai_core.Utility.functions import count_tokens_str
from azure.search.documents.models import VectorFilterMode
from typing import List, Dict, Optional  


class IndexType(Enum):
    FAISS = "FAISS"
    AZCOGNITIVESEARCH = "Azure Cognitive Search"
    MILVUS = "Milvus"

class BaseIndexer():
    """
    A base class for vector indexers that provides common functionality.
    """
    service_url: str
    index_name: str
    api_key: str
    openai_utility: OpenAIUtility
    index_type: IndexType

    def __init__(self, service_url, index_name, api_key, openai_utility, index_type):
        self.service_url = service_url
        self.index_name = index_name
        self.api_key = api_key
        self.openai_utility = openai_utility
        self.index_type = index_type

class VectorDbIndexer:
    @staticmethod
    def get_index(index_type: IndexType, azure_cognitive_search_service_url, index_name, api_key, openai_utility: OpenAIUtility):
        if index_type == IndexType.AZCOGNITIVESEARCH:
            return AZCognitiveSearchIndexer(openai_utility, azure_cognitive_search_service_url, index_name, api_key)
        else:
            raise ValueError("Configured Indexer is not supported for this operation")

class AZCognitiveSearchIndexer(BaseIndexer):
    """
    A class for building and retrieving Azure Cognitive search indexes.
    """

    def __init__(self, openai_utility, azure_cognitive_search_service_url, index_name, api_key, index_type: IndexType = IndexType.AZCOGNITIVESEARCH):
        super().__init__(service_url=azure_cognitive_search_service_url, index_name=index_name, api_key=api_key,
                         openai_utility=openai_utility, index_type=index_type)

    async def get_all_content_chunks(self, documentid: str, fields: List[str] = ["FileName", "Content", "PageNumber", "DocumentId"]) -> Optional[Dict[int, str]]:  
        try:  
            credential = AzureKeyCredential(self.api_key) if self.api_key else DefaultAzureCredential()  
            search_client = SearchClient(  
                endpoint=self.service_url,  
                index_name=self.index_name,  
                credential=credential  
            )  
            
            results = search_client.search(  
                search_text="*",  
                filter=f"DocumentId eq '{documentid}'",  
                order_by=["SequenceId"],  
                include_total_count=True,  
                select=fields  
            )  
            
            page_content_dict = {}  
            
            for result in results:  
                page_number = result.get("PageNumber")  
                content_parts = []  
                
                for field in fields:  
                    field_value = result.get(field)  
                    if field_value is not None:  
                        content_parts.append(f'{field}: {field_value}')  
                
                if page_number is not None and content_parts:  
                    page_content_dict[page_number] = ', '.join(content_parts)  
            
            logging.info(f"Retrieved content for document ID {documentid}: {len(page_content_dict)} pages found.")  
            
            return page_content_dict  
    
        except Exception as e:  
            logging.error(f"Error while retrieving documents for DocumentId {documentid}: {str(e)}")  
            return None  

    
    async def get_relevant_content(self, user_query: str, embedding_deloyment_name: str,user_id: str,fields: List[str] = ["FileName", "Content"],filter_fields: Dict = None,Top:int=4):
        try:
            credential = AzureKeyCredential(self.api_key) if self.api_key else DefaultAzureCredential()

            search_client = SearchClient(endpoint=self.service_url,
                                         index_name=self.index_name,
                                         credential=credential)
            
            if(embedding_deloyment_name is None or embedding_deloyment_name == ""):
                embedding_deloyment_name = "text-embedding-3-large"

            user_query_embedding =await self.openai_utility.generate_embeddings_async(user_query, embedding_deloyment_name)
            vector_query = VectorizedQuery(vector=user_query_embedding, k_nearest_neighbors=3, fields="ContentVector")
            
            # Initialize filter condition
            filter_condition = None
        
            if filter_fields and isinstance(filter_fields, dict):
                filter_condition_parts = []
                for key, value in filter_fields.items():
                    if value:  # Only include non-empty values
                        if key.startswith("exclude_"):  
                            field_name = key[len("exclude_"):]  
                            if field_name not in fields:
                                fields.append(field_name)
                            filter_condition_parts.append(f"{field_name} ne '{value}'")  
                        else:  
                            filter_condition_parts.append(f"{key} eq '{value}'")
                            if key not in fields:
                                fields.append(key)  
                if filter_condition_parts:
                    filter_condition = " and ".join(filter_condition_parts)
                
            results = search_client.search(
                search_text=user_query,
                vector_queries=[vector_query],
                vector_filter_mode=VectorFilterMode.PRE_FILTER,
                select=fields, top=Top, filter=filter_condition
            )
            
            if results:
                counter = 0
                content = None
                for result in results:
                    if counter > 4:
                        return content
                    page_content_parts = []
                    for field in fields:
                        field_value = result.get(field)
                        if field_value is not None:
                            page_content_parts.append(f'{field}: {field_value}')
                    page_content = ', '.join(page_content_parts)
                    if page_content:
                        if content is None:
                            content = page_content
                        else:
                            content += ", " + page_content
                    counter += 1
                if content is not None:
                    try:
                        logging.info(f'total token count :{count_tokens_str(content)}')
                    except Exception as e:
                        logging.error(f"Error while counting tokens: {str(e)}")
                return content
            else:
                return None
        except Exception as e:
            logging.error(f"Error while getting the relevant documents: {str(e)}")
            raise e

