import logging
from azure.cosmos import CosmosClient, exceptions
from azure.identity import DefaultAzureCredential

class CosmosDBDataProcessor:
    def __init__(self, endpoint, key, database_name, container_name, connection_pool_size=10):
        self.endpoint = endpoint
        self.key = key
        self.database_name = database_name
        self.container_name = container_name
        self.connection_pool_size = connection_pool_size
        self.client = None
        self.logger = logging

    async def __aenter__(self):
        try:
            if self.key is None or self.key == "":
                credentials = DefaultAzureCredential()
            else:
                credentials = self.key
            self.client = CosmosClient(self.endpoint, credentials)
            self.logger.info("Connected to Cosmos DB")
            return self
        except Exception as e:
            self.logger.error(f"Error connecting to Cosmos DB: {e}")
            raise RuntimeError(f"Error connecting to Cosmos DB: {e}")

    async def __aexit__(self, exc_type, exc_value, traceback):
        if self.client:
            self.logger.info("Closing Cosmos DB client")

    async def get_container_client(self):
        try:
            database = self.client.get_database_client(self.database_name)
            container = database.get_container_client(self.container_name)
            return container
        
        except Exception as e:
            self.logger.error(f"Error getting container client: {e}")
            raise RuntimeError(f"Error getting container client: {e}")

    async def query_documents(self, query, parameters=None):
        try:
            container = await self.get_container_client()
            items = list(container.query_items(query, parameters=parameters))
            return items
        except Exception as e:
            self.logger.error(f"Error executing query: {e}")
            raise ValueError(f"Error executing query: {e}")

    async def insert_document(self, document):
        try:
            container = await self.get_container_client()
            container.upsert_item(document)
            self.logger.info("Document inserted successfully")
        except Exception as e:
            self.logger.error(f"Error inserting document: {e}")
            raise ValueError(f"Error inserting document: {e}")

    async def read_document(self, item_id, partition_key):
        try:
            container = await self.get_container_client()
            # Check if the document exists
            document_exists_flag = await self._document_exists(container, item_id)
            if not document_exists_flag and item_id == 'Procurement':
                # If the document does not exist, create a new one
                item = {
                    "id": item_id,
                    "promptkey": item_id,
                    "Category": "Procurement",
                    "children": []
                }
                container.create_item(item)
            else:
                item = container.read_item(item=item_id, partition_key=partition_key)
            return item            
        
        except Exception as e:
            self.logger.error(f"Error reading document: {e}")
            raise ValueError(f"Error reading document: {e}")
        
    async def update_document_content(self, item_id, partition_key, updated_content):
        try:
            container = await self.get_container_client()
            item = container.read_item(item=item_id, partition_key=partition_key)
            item['content'] = updated_content
            container.upsert_item(item)
            self.logger.info("Document updated successfully")
        except Exception as e:
            self.logger.error(f"Error updating document: {e}")
            raise ValueError(f"Error updating document: {e}")
    async def update_request_template(self, agentkey, query_type, updated_template):
        try:
            # Get the container client
            container = await self.get_container_client()

            # Read the item based on the agentkey
            item = container.read_item(item=agentkey, partition_key=agentkey)

            # Find the request template by QueryType and update it
            for template in item['request_template']:
                if template['QueryType'] == query_type:
                    template.update(updated_template)  # Update the template with the new data
                    break
            else:
                raise ValueError(f"QueryType '{query_type}' not found in request_template")

            # Upsert (update or insert) the modified document
            container.upsert_item(item)
            self.logger.info(f"Document with agentkey '{agentkey}' updated successfully")
        
        except Exception as e:
            self.logger.error(f"Error updating document: {e}")
            raise ValueError(f"Error updating document: {e}")

    async def update_document_child_content(self, item_id, partition_key, child_key, updated_content):
        try:
            container = await self.get_container_client()
            
            # Read the document from Cosmos DB
            item = container.read_item(item=item_id, partition_key=partition_key)
            
            # Define a recursive function to find and update the specific child by key
            def update_child_by_key(parent, key):
                # Check if the current parent has 'children'
                if 'children' in parent:
                    for child in parent['children']:
                        if child['key'] == key:
                            # Update the 'Content' field of the specific child
                            child['Content'] = updated_content
                            return True
                        
                        # If the child has its own children, recursively search them
                        if 'children' in child:
                            found = update_child_by_key(child, key)
                            if found:
                                return True
                return False
            
            # Start by searching for the child in the root document
            child_updated = update_child_by_key(item, child_key)
            
            if not child_updated:
                raise ValueError(f"Child with key '{child_key}' not found")
            
            # Upsert the modified item back into Cosmos DB
            container.upsert_item(item)
            self.logger.info("Child document updated successfully")
    
        except Exception as e:
            self.logger.error(f"Error updating document: {e}")
            raise ValueError(f"Error updating document: {e}")

    async def create_document(self, item_id, content):
        try:
            container = await self.get_container_client()
            document = {
                'id': item_id,
                'content': content
            }
            container.create_item(document)
            self.logger.info("Document created successfully")
        except Exception as e:
            self.logger.error(f"Error creating document: {e}")
            raise ValueError(f"Error creating document: {e}")
    
    async def create_prompt(self, item_id, children,category):
        try:
            # Get container client
            container = await self.get_container_client()
            
            # Construct the document with promptkey derived from item_id (which is the 'Id' field in the payload)
            document = {
                'id': item_id,
                'promptkey': item_id,  # Use the same item_id as promptkey
                'Category': category,  # Fetch 'Category' from the payload
                'children': children  # Add 'children' key as a list containing the 'Children' object
            }
            
            # Create the document in Cosmos DB
            container.create_item(document)
            self.logger.info("Document created successfully")
            
        except Exception as e:
            self.logger.error(f"Error creating document: {e}")
            raise ValueError(f"Error creating document: {e}")
    
    async def create_agent(self, agent_id, agent_data):
        try:
            # Get the container client
            container = await self.get_container_client()
            
            # Construct the document for the agent
            document = {
                'id': agent_id,  # Use the agent's name or ID as the document's ID
                'agentkey': agent_data['agentkey'],  # Use agentkey from the provided data
                'AgentName': agent_data['AgentName'], 
                'module':agent_data['module'],
                'class':agent_data['class'],# Use AgentName from the payload
                'AgentDescription': agent_data['AgentDescription'],  # Use description from the payload
                'service_url': agent_data['service_url'],  # Use service_url from the payload
                'authentication': agent_data['authentication'],  # Use authentication object from the payload
                'required_fields': agent_data['required_fields'],  # Use required fields from the payload
                'request_template': agent_data['request_template']  # Add the request template
            }
            
            # Create the document in Cosmos DB
            container.create_item(document)
            self.logger.info("Agent document created successfully")
            
        except Exception as e:
            self.logger.error(f"Error creating agent document: {e}")
            raise ValueError(f"Error creating agent document: {e}")

    async def create_update_mapping_document(self, item_id, partition_key, new_mapping_key, new_mapping_value):
        try:
            container = await self.get_container_client()
            item = container.read_item(item=item_id, partition_key=partition_key)
            # If the document exists but does not have a mapping key, create a new mapping key
            if 'mapping' not in item:
                item['mapping'] = {}
            # Create or update the mapping key
            item['mapping'][new_mapping_key] = new_mapping_value
            container.upsert_item(item)
            self.logger.info("Document created successfully")
        except Exception as e:
            self.logger.error(f"Error creating document: {e}")
            raise ValueError(f"Error creating document: {e}")
        
    
    async def _document_exists(self, container, document_id):
        query = "SELECT VALUE COUNT(1) FROM c WHERE c.id = @document_id"
        parameters = [{"name": "@document_id", "value": document_id}]
        items = container.query_items(query=query, parameters=parameters, enable_cross_partition_query=True)
    
        count = 0
        for item in items:
            count = item
            break
        
        return count > 0

    async def fetch_all_documents(self):
        try:
            container = await self.get_container_client()
            # Fetch all items from the container using read_all_items
            items_paged = container.read_all_items()
            items = [item for item in items_paged]  # Synchronously iterate over the paged results
            
            return items
        except Exception as e:
            self.logger.error(f"Error fetching all documents: {e}")
            raise ValueError(f"Error fetching all documents: {e}")