import json
from typing import Optional
import logging
from askai_core.common import BaseCacheWrapper, CacheFactory, CacheType
from askai_core.common import LLMModelConfiguration
from askai_core.common import OpenAIUtility
from askai_core.Utility.prompts import FABRICS_SQL_PROMPT_TEMPLATE, GRAPH_SQL_PROMPT
from askai_core.Utility.functions import log_execution_time
from azure.identity import ClientSecretCredential
import pyodbc  
import struct  
import asyncio


class FabricQueryProcessor:
    def __init__(
        self,
        fabric_tenantid: str,
        fabric_clientid: str,
        fabric_clientsecret: str,
        fabric_api_url: str,
        fabric_sql_connection_string: str,
        GPT_4_32_MODEL: str,
        openaiutility: OpenAIUtility,
        cache :BaseCacheWrapper
    ):
        self.params = {
            'fabric_tenantid': fabric_tenantid,
            'fabric_clientid': fabric_clientid,
            'fabric_clientsecret': fabric_clientsecret,
            'fabric_api_url': fabric_api_url,
            'fabric_sql_connection_string': fabric_sql_connection_string,
            'GPT_4_32_MODEL': GPT_4_32_MODEL,
            'openaiutility': openaiutility,
            'cache': cache
        }
        self.openaiutility :OpenAIUtility = self.params['openaiutility']
        self.cache  = self.params['cache']

    def get_auth_token(self) -> Optional[str]:
        try:
            auth = ClientSecretCredential(
                tenant_id=self.params['fabric_tenantid'],
                client_id=self.params['fabric_clientid'],
                client_secret=self.params['fabric_clientsecret'],
            )
            access_token = auth.get_token(self.params['fabric_api_url'])
            return access_token.token
        except Exception as e:
            logging.error(str(e))
            raise e

    def get_token_struct(self, access_token: str):
        token_bytes = bytes(access_token, "UTF-8")
        exptoken = b""
        for i in token_bytes:
            exptoken += bytes({i})
            exptoken += bytes(1)
        return struct.pack("=i", len(exptoken)) + exptoken

    @log_execution_time
    def execute_database_query(self, query: str):
        try:
            cache_query_key = f'FabricQuery_X{query}'
            cache_query_counter = f'FabricQueryCounter_X{query}'
            cache_query_result = self.cache.read_from_cache(cache_query_key)
            if cache_query_result is not None:
                cache_counter = self.cache.read_from_cache(cache_query_counter)
                return cache_query_result, cache_counter

            access_token = self.get_auth_token()
            if access_token is None:
                return None

            token_struct = self.get_token_struct(access_token)
            connection_string =self.params['fabric_sql_connection_string']
            logging.info(f'connection string is {connection_string}')
            conn = pyodbc.connect( connection_string, attrs_before={1256:bytearray(token_struct)})  
            
            result = conn.execute(query)
            result_str = ""
            counter = 0
            if result is None:
                return None, 0
            for row in result:
                counter += 1
                if counter > 100:
                    break
                else:
                    result_str += str(row) + "\n"
            conn.close()
            logging.info(f'Query result row count is {counter}')
            if counter == 0:
                return None, 0
            self.cache.write_to_cache(cache_query_key, result_str, 15000)
            self.cache.write_to_cache(cache_query_counter, counter, 15000)
            return result_str, counter
        except TypeError as e:
            logging.error(str(e))
            return None, 0
        except Exception as e:
            logging.error(str(e))
            return None, 0
        
    @log_execution_time
    def execute_database_query_with_json_response(self, query: str):
        try:
            cache_query_key = f'FabricQueryWithJsonResponse_X{query}'
            cache_query_result = self.cache.read_from_cache(cache_query_key)
            if cache_query_result is not None:
                return cache_query_result

            access_token = self.get_auth_token()
            if access_token is None:
                return None

            token_struct = self.get_token_struct(access_token)
            connection_string =self.params['fabric_sql_connection_string']
            logging.info(f'connection string is {connection_string}')
            conn = pyodbc.connect( connection_string, attrs_before={1256:bytearray(token_struct)})  
            
            result = conn.execute(query)
            rows = result.fetchall()
            
            columns = [column[0] for column in result.description]

            result.close()
            conn.close()

            data = []
            for row in rows:
                data.append(dict(zip(columns, row)))
                
            json_data = json.dumps(data)
            
            if json_data is not None:
                self.cache.write_to_cache(cache_query_key, json_data, 15000)
            
            return json_data
        except TypeError as e:
            logging.error(str(e))
            return None
        except Exception as e:
            logging.error(str(e))
            return None

    def get_database_query_result(self, sqlquery: str, userquery: str):
        sqlresult, counter = self.execute_database_query(sqlquery)

        if sqlresult is None or sqlquery == "" or counter == 0:
            sqlresult = "no result found for the query"
        try:
            FABRICS_SQL_USER_PROMPT="{}, Database Query :{},Database Query Response :{}"
            #FABRICS_SQL_USER_PROMPT.format(userquery, sqlquery, sqlresult)
            prompt = [
                {"role": "system", "content": FABRICS_SQL_PROMPT_TEMPLATE},
                {"role": "user", "content": f' user query :{userquery}, database sql query:{sqlquery}, database SQL query execution result:{sqlresult}, response:' },
            ]
            if int(counter) > 20:
                gptmodel = self.params['GPT_4_32_MODEL']
            else:
                gptmodel = LLMModelConfiguration.get_instance().GPT_35_TURBO
            
            result= self.openaiutility.generate_completion_sync(prompt, gptmodel, 2048)
            return result
        except Exception as e:
            logging.error(str(e))
            raise e

    def get_database_query_graph(self, sqlquery: str, userquery: str):
        sqlresult, counter = self.execute_database_query(sqlquery)

        if sqlresult is None or sqlquery == "" or counter == 0:
            sqlresult = "no result found for the query"
        try:
            FABRICS_SQL_USER_PROMPT="{}, Database Query :{},Database Query Response :{}"
            prompt = [
                {"role": "system", "content": GRAPH_SQL_PROMPT},
                {"role": "user", "content": FABRICS_SQL_USER_PROMPT.format(userquery, sqlquery, sqlresult)},
            ]
            if int(counter) > 20:
                gptmodel = self.params['GPT_4_32_MODEL']
            else:
                gptmodel = LLMModelConfiguration.get_instance().GPT_35_TURBO

            result= self.openaiutility.generate_completion_sync(prompt, gptmodel, 2048)
            return result, counter
        except Exception as e:
            logging.error(str(e))
            raise e
