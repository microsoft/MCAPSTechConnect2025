from azure.cosmos import CosmosClient
from azure.identity import DefaultAzureCredential


class CosmosUtility:
    def __init__(self, endpoint, key, database_name, container_name):
        if key is None or key == "":
            credentials = DefaultAzureCredential()
        else:
            credentials = key
        self.client = CosmosClient(endpoint, credentials)
        self.database = self.client.get_database_client(database_name)
        self.container = self.database.get_container_client(container_name)

    def create_item(self, item):
        response = self.container.create_item(item)
        return response

    def read_item(self, item_id):
        response = self.container.read_item(item_id)
        return response
    
    def query_items(self, query, parameters=None):
        items = list(self.container.query_items(query, parameters=parameters))
        return items

    def update_item(self, item_id, updated_item):
        item = self.read_item(item_id)
        item.update(updated_item)
        response = self.container.replace_item(item_id, item)
        return response

    def delete_item(self, item_id):
        response = self.container.delete_item(item_id)
        return response