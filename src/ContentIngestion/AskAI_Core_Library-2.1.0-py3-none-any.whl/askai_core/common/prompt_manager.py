import os
import json
import aiofiles
from askai_core.data_insight import CosmosDBDataProcessor

class AskAIPromptManager:
    def __init__(self, source='local', prompt_data=None, cosmos_db_processor : CosmosDBDataProcessor=None):
        self.source = source
        self.context_prompt_data = prompt_data or {}
        self.cosmos_db_processor = cosmos_db_processor

    @classmethod
    async def load(cls, source='local', prompt_file_path=None, cosmos_db_processor :CosmosDBDataProcessor=None):
        if source == 'local':
            try:
                async with aiofiles.open(prompt_file_path,'r', encoding='utf-8', errors='ignore') as file:
                    content = await file.read()
                    loaded_data = json.loads(content)
                    return cls(source=source, prompt_data=loaded_data)
            except FileNotFoundError:
                raise ValueError(f"File not found: {prompt_file_path}")
            except json.JSONDecodeError:
                raise ValueError(f"Failed to decode JSON in file: {prompt_file_path}")
        elif source == 'cosmos' and cosmos_db_processor:
            instance = cls(source=source, cosmos_db_processor=cosmos_db_processor)
            await instance._load_prompt_mapping_from_cosmos()
            return instance
        else:
            raise ValueError(f"Invalid source: {source} or Cosmos DB processor not provided")

    async def _load_prompt_mapping_from_cosmos(self):
        try:
            prompt_id = "prompt_mapping"
            mapping_item = await self.cosmos_db_processor.read_document(item_id=prompt_id, partition_key=prompt_id)
            self.context_prompt_data = mapping_item.get('mapping', {})
        except ValueError as e:
            raise ValueError(f"Error fetching prompt mapping file from Cosmos DB: {str(e)}")

    async def get_all_prompts(self):
        return self.context_prompt_data
    
    async def get_prompt(self, key,directoryPath=None):
        prompt_file_name = self.context_prompt_data.get(key, self.context_prompt_data.get('Default'))
        if not prompt_file_name:
            raise ValueError(f"No prompt file name found for key: {key}")

        if self.source == 'local':
            if directoryPath is None:
                return await self._fetch_prompt_from_local(prompt_file_name)
            else:
                return await self._fetch_prompt_from_local(prompt_file_name,directoryPath)
        elif self.source == 'cosmos':
            return await self._fetch_prompt_from_cosmos(prompt_file_name)
        else:
            raise ValueError(f"Invalid source: {self.source}")

    async def _fetch_prompt_from_local(self, file_name):
        try:
            file_path = os.path.join(os.path.dirname(__file__), file_name)
            async with aiofiles.open(file_path,'r', encoding='utf-8', errors='ignore') as file:
                return await file.read()
        except FileNotFoundError:
            raise ValueError(f"Prompt file {file_name} not found locally.from path{file_path}")
        except Exception as e:
            raise ValueError(f"Error fetching prompt file {file_name} locally: {str(e)}")
        
    async def _fetch_prompt_from_local(self, file_name, directoryPath):
        try:
            file_path = os.path.join(directoryPath, file_name)
            async with aiofiles.open(file_path,'r', encoding='utf-8', errors='ignore') as file:
                return await file.read()
        except FileNotFoundError:
            raise ValueError(f"Prompt file {file_name} not found locally.from path{file_path}")
        except Exception as e:
            raise ValueError(f"Error fetching prompt file {file_name} locally: {str(e)}")

    async def _fetch_prompt_from_cosmos(self, file_name):
        try:
            prompt_item = await self.cosmos_db_processor.read_document(item_id=file_name, partition_key=file_name)
            return prompt_item.get('content')
        except ValueError as e:
            raise ValueError(f"Error fetching prompt file {file_name} from Cosmos DB: {str(e)}")

    async def update_prompt(self, key, content):
        prompt_file_name = self.context_prompt_data.get(key, self.context_prompt_data.get('Default'))
        if not prompt_file_name:
            raise ValueError(f"No prompt file name found for key: {key}")
        try:
            await self.cosmos_db_processor.update_document_content(item_id=prompt_file_name, partition_key=prompt_file_name, updated_content=content)
            return (f"Successfully updated content of prmopt file {prompt_file_name}")
        except ValueError as e:
            raise ValueError(f"Error updating prompt file {prompt_file_name}: {str(e)}")
    
    async def create_prompt(self, prompt_id, content, category):
        key = f"{category}_{prompt_id}"
        prompt_file_name = self.context_prompt_data.get(key, self.context_prompt_data.get('Default'))
        if prompt_file_name:
            return (f"Prompt with this file name -  {prompt_file_name} already exists. Please use update_prompt method to update the content.")
        else:
            prompt_file_name = key
            try:
                await self.cosmos_db_processor.create_document(item_id=prompt_file_name, content=content)
                await self.cosmos_db_processor.create_update_mapping_document(item_id='prompt_mapping', partition_key='prompt_mapping', new_mapping_key=prompt_file_name, new_mapping_value=prompt_file_name)
                return (f"Successfully created prompt file {prompt_file_name}")
            except ValueError as e:
                raise ValueError(f"Error creating prompt file {prompt_file_name}: {str(e)}")