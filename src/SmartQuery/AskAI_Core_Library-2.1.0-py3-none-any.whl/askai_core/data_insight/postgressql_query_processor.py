# import psycopg2
# import logging
# from psycopg2 import pool

# class PostgresSQLQueryProcessor:
#     def __init__(self, host, dbname, user, password, sslmode='require'):
#         self.host = host
#         self.dbname = dbname
#         self.user = user
#         self.password = password
#         self.sslmode = sslmode
#         self.conn_pool = None

#     def __enter__(self):
#         self.connect()
#         return self

#     def __exit__(self, exc_type, exc_value, traceback):
#         self.close()

#     def connect(self):
#         try:
#             self.conn_pool = psycopg2.pool.SimpleConnectionPool(1, 10, 
#                 host=self.host, database=self.dbname, user=self.user,
#                 password=self.password, sslmode=self.sslmode)
#             logging.info("Connection pool created")
#         except psycopg2.Error as e:
#             logging.error("Error creating connection pool: %s", e)

#     def execute_query(self, query, params=None):
#         conn = self.conn_pool.getconn()
#         try:
#             with conn.cursor() as cursor:
#                 cursor.execute(query, params)
#                 result = cursor.fetchall()
#                 return result
#         except psycopg2.Error as e:
#             logging.error("Error executing query: %s", e)
#         finally:
#             self.conn_pool.putconn(conn)

#     def close(self):
#         if self.conn_pool:
#             self.conn_pool.closeall()
#             logging.info("Connection pool closed")
