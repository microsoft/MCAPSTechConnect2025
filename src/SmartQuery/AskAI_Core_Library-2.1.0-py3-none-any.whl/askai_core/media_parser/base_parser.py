
class BaseParser:
    def __init__(self, token_size:int,auth_url: str,auth_params:dict, client_id:str, client_secret:str, tenant_id:str, file_ext: str, file_video_id: str = None):
        self.auth_url = auth_url
        self.auth_params = auth_params
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant_id = tenant_id
        self.file_ext = file_ext
        self.file_video_id = file_video_id
        self.token_size = token_size

    async def extract_transcript(self) :
        raise NotImplementedError("Subclasses must implement extract_transcript method.")
    
    async def extract_keywords(self) :
        raise NotImplementedError("Subclasses must implement extract_keywords method.")
    
    async def extract_namedPeople(self) :
        raise NotImplementedError("Subclasses must implement extract_namedPeople method.")