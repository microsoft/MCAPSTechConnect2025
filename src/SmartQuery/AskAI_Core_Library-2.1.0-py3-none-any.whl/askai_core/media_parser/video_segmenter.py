import os
import sys
import math
from moviepy.editor import VideoFileClip
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import logging 

def validate_segment_duration(segment_duration):
    
    if not isinstance(segment_duration, (int, float)) or segment_duration <= 0:
        raise ValueError("Segment duration must be a positive number.")

def validate_save_as_audio(save_as_audio):
    
    if not isinstance(save_as_audio, bool):
        raise ValueError("save_as_audio parameter must be a boolean value.")

def save_segment(segment, segment_filename, save_as_audio, output_directory):
    
    try:
        if save_as_audio:
            segment_filename += ".mp3"  # or any other audio format
            segment.audio.write_audiofile(segment_filename)
        else:
            segment_filename += ".mp4"  # or any other video format
            segment.write_videofile(segment_filename, codec="libx264", audio_codec="aac")
    except Exception as e:
        logging.error(f"Error while saving segment: {e}")
    else:
        logging.info(f"Segment saved: {segment_filename}")

def split_video_into_segments(video_file, segment_duration=100, save_as_audio=True, output_directory=None):
    try:
        
        validate_segment_duration(segment_duration)
        validate_save_as_audio(save_as_audio)

        
        video = VideoFileClip(video_file)

        total_duration = video.duration

        # Calculate the number of segments needed
        num_segments = math.ceil(total_duration / segment_duration)

        # Create output directory if not exists
        if output_directory:
            output_directory = os.path.abspath(output_directory)
            Path(output_directory).mkdir(parents=True, exist_ok=True)

        segments_info = []

        def process_segment(i):
            try:
                start_time = i * segment_duration
                end_time = min((i + 1) * segment_duration, total_duration)

                segment = video.subclip(start_time, end_time)

                # Generate a filename for the segment
                segment_filename = f"{video_file}__segment__{i+1}"
                if output_directory:
                    segment_filename = os.path.join(output_directory, segment_filename)

                save_segment(segment, segment_filename, save_as_audio, output_directory)

                segment_path = os.path.abspath(segment_filename)

                segment_info = {
                    "segment_id": i + 1,
                    "start_time": start_time,
                    "end_time": end_time,
                    "file_path": segment_path
                }
                segments_info.append(segment_info)

                segment.close()
            except Exception as e:
                logging.error(f"Error processing segment {i+1}: {e}")

        with ThreadPoolExecutor(max_workers=os.cpu_count()) as executor:
            executor.map(process_segment, range(num_segments))

        video.close()

        return segments_info
    except Exception as e:
        logging.error(f"Error: {e}")
        return None

