from typing import Optional

from askai_core.media_parser import BaseParser
from askai_core.media_parser import AzureVideoParser



class ParserFactory:
    @staticmethod
    def create_parser(token_size:int, auth_url: str,auth_params:dict, client_id:str, client_secret:str, tenant_id:str, file_ext: str, file_video_id: str = None) -> Optional[BaseParser]:
        
        if file_ext in ['.mp4', '.mov']:
            return AzureVideoParser(token_size, auth_url,auth_params, client_id, client_secret, tenant_id, file_ext, file_video_id)
        else:
            return None