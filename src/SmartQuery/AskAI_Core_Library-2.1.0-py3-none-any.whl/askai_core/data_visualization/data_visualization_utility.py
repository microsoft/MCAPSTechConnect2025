import json
import logging
import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO, StringIO
import base64

import matplotlib.cm as cm
from matplotlib.ticker import ScalarFormatter
import warnings
warnings.simplefilter("ignore", category=FutureWarning)

class DataVisualizationUtility:
    MILLION_THRESHOLD = 1e7

    
    async def generate_chart_from_file(self, req_schema, account_name, account_key, container_name, sas_url_expiry_window):
        try:
            schema = req_schema
            file = req_schema.files['file']
            csv_data = StringIO(file.read().decode('utf-8'))
            df = pd.read_csv(csv_data, skipinitialspace=True)
            return await self._generate_chart(df, schema, account_name, account_key, container_name, sas_url_expiry_window)

       
        except Exception as e:
            logging.error(f"Error while generating chart from file: {str(e)}")
            raise e

    async def generate_chart_from_data(self, req_schema):
        try:
            req_schema=json.loads(req_schema)
            schema = req_schema.get('schema')
            data = req_schema.get('data')
            df = pd.DataFrame(data)
            pd.set_option('display.float_format', '{:.8f}'.format)
            return await self._generate_chart(df, schema)

       
        except Exception as e:
            logging.error(f"Error while generating chart from data: {str(e)}")
            raise e

    async def _generate_chart(self, df, schema):
        try:
            df = df.apply(pd.to_numeric, errors='ignore')
            chart_type = schema.get('chart_type')
            x_label = schema.get('xlabel')
            y_label = schema.get('ylabel')

            if x_label not in df.columns or y_label not in df.columns:
                raise ValueError("Invalid column")

            if pd.api.types.is_float_dtype(df[x_label]):
                df[x_label] = df[x_label].round(0).astype(int)

            if pd.api.types.is_float_dtype(df[y_label]):
                df[y_label] = df[y_label].round(0).astype(int)

            await self._dispatch_chart_generation(chart_type, df, x_label, y_label)

            chart_type_pascal = ''.join(word.capitalize() for word in chart_type.split('_'))
            plt.title(f'{chart_type_pascal} Chart')

            chart_buffer = BytesIO()
            plt.savefig(chart_buffer, format='png')
            plt.close()

            logging.info(f"{chart_type} chart generated successfully.")
            return chart_buffer.getvalue()

       
        except Exception as e:
            logging.error(f"Error while generating chart: {str(e)}")
            raise e

    async def _dispatch_chart_generation(self, chart_type, df, x_label, y_label):
        try:
            generate_method = getattr(self, f'_generate_{chart_type.lower()}_chart')
            await generate_method(df, x_label, y_label)

        except AttributeError:
            raise ValueError("Invalid chart type")

    async def _generate_bar_chart(self, df, x_label, y_label):
        try:
            legend_labels = []
            x_axis_has_text = False

            if pd.api.types.is_string_dtype(df[x_label]):
                label_abbreviations = {}

                for category in df[x_label]:
                    if isinstance(category, str) and len(category) >= 3:
                        abbreviation = category[:3]
                        label_abbreviations[category] = abbreviation + '..'
                        x_axis_has_text = True

                df_labels = pd.DataFrame({
                    'Original_Label': df[x_label],
                    'Abbreviation': df[x_label].map(label_abbreviations)
                })

                df = pd.merge(df, df_labels, left_on=x_label, right_on='Original_Label', how='left')

            if x_axis_has_text:
                unique_labels = df[x_label].unique()
                color_map = cm.get_cmap('viridis', len(unique_labels))
                bars = plt.bar(df['Abbreviation'], df[y_label], color=[color_map(i) for i in range(len(unique_labels))])
                legend_labels = unique_labels
            else:
                unique_labels = df[x_label].unique()
                color_map = cm.get_cmap('viridis', len(unique_labels))
                bars = plt.bar(df[x_label], df[y_label], color=[color_map(i) for i in range(len(unique_labels))])
                plt.xticks(df[x_label])
                legend_labels = unique_labels

                max_y_label = max(df[y_label])
                if max_y_label > self.MILLION_THRESHOLD:
                    plt.gca().yaxis.set_major_formatter(ScalarFormatter(useMathText=False))
                    plt.ticklabel_format(style='plain', axis='y')
                    plt.ylim(0, max_y_label)
                    plt.yticks(range(0, int(max_y_label) + 1, int(max_y_label / 8)))

            plt.xlabel(f'{x_label}')
            plt.ylabel(f'{y_label}')
            plt.legend(bars, legend_labels)

        except Exception as e:
            logging.error(f"Error while generating bar chart: {str(e)}")
            raise e

    async def _generate_pie_chart(self, df, x_label, y_label):
        try:
            plt.pie(df[y_label], labels=df[x_label], autopct='%1.1f%%', startangle=140)
            plt.axis('equal')

        except Exception as e:
            logging.error(f"Error while generating pie chart: {str(e)}")
            raise e

    async def _generate_line_chart(self, df, x_label, y_label):
        try:
            x2,y2 = zip(*sorted(zip(df[x_label], df[y_label]),key=lambda x: x[0]))

            plt.plot(x2,y2, marker='o', linestyle='-', color='b')
            plt.xlabel(f'{x_label}')
            plt.ylabel(f'{y_label}')

        except Exception as e:
            logging.error(f"Error while generating line chart: {str(e)}")
            raise e

    async def _generate_spline_chart(self, df, x_label, y_label):
        try:
            plt.figure(figsize=(8, 6))
            plt.plot(df[x_label], df[y_label], marker='o', linestyle='-', color='b')
            plt.xlabel(x_label)
            plt.ylabel(y_label)
            plt.legend()

        except Exception as e:
            logging.error(f"Error while generating spline chart: {str(e)}")
            raise e

    async def _generate_scatter_chart(self, df, x_label, y_label):
        try:
            plt.scatter(df[x_label], df[y_label], color='blue', marker='o')
            plt.xlabel(f'{x_label}')
            plt.ylabel(f'{y_label}')

        except Exception as e:
            logging.error(f"Error while generating scatter chart: {str(e)}")
            raise e

    async def convert_chart_to_base64(self, content_bytes):
        try:
            base64_chart = base64.b64encode(content_bytes).decode('utf-8')
            return base64_chart

        except Exception as e:
            logging.error(f"Error while generating base 64 from bytes: {str(e)}")
            raise e
