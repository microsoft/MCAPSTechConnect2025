from io import BytesIO
import logging
from pptx import Presentation  
from pptx.util import Pt, Inches  
from pptx.dml.color import RGBColor  
from pptx.enum.chart import XL_CHART_TYPE  
from pptx.enum.text import PP_ALIGN


import json  
  
class SlideBuilder:  
    def __init__(self, template_path=None):  
        self.template_path  = template_path  
        self.prs  = Presentation(template_path) if template_path else Presentation()
      
    def set_font_properties(self, cell, font_size=Pt(12), bold=False, italic=False, color=RGBColor(0, 0, 0)):  
        paragraph = cell.text_frame.paragraphs[0]  
        run = paragraph.runs[0]  
        run.font.size = font_size  
        run.font.bold = bold  
        run.font.italic = italic  
        run.font.color.rgb = color  
      
    def add_text_slide(self, title, content):  
        slide_layout = self.prs.slide_layouts[1]  # Using layout 1 which typically has a title and content  
        slide = self.prs.slides.add_slide(slide_layout)  
        title_shape = slide.shapes.title  
        title_shape.text = title  
        content_shape = slide.placeholders[1]  
        content_shape.text = content  
        self.set_font_properties(title_shape, font_size=Pt(24), bold=True, color=RGBColor(0, 102, 204))  
        self.set_font_properties(content_shape, font_size=Pt(18))  
      
  
    def add_table_slide(self, title, table_data):  
        slide_layout = self.prs.slide_layouts[5]  # Using a blank slide layout  
        slide = self.prs.slides.add_slide(slide_layout)  
        title_shape = slide.shapes.title  
        title_shape.text = title  
  
        # Table dimensions  
        num_rows = len(table_data['rows']) + 1  # Adding one for the header row  
        num_cols = len(table_data['headers'])  
  
        # Adding a table to the slide  
        # Note: You might need to adjust the left, top, width, and height to fit your template  
        left = Inches(2)  
        top = Inches(2.7)  
        width = Inches(9)  
        height = Inches(0.8)  
        shape =slide.shapes.add_table(num_rows, num_cols, left, top, width, height)
        tbl =  shape._element.graphic.graphicData.tbl
        LightStyle1Accent4 = '{D27102A9-8310-4765-A935-A1911B00CA55}'
        tbl[0][-1].text = LightStyle1Accent4  
        table = shape.table  
  
        # Set column headings  
        for col_idx, header in enumerate(table_data['headers']):  
            logging.info(f"Adding header: {header}")
            cell = table.cell(0, col_idx)  
            cell.text = header  
            # You can add additional formatting for the header cell here  
            self.set_font_properties(cell, font_size=Pt(12), bold=True)  
  
        # Fill in the table rows  
        for row_idx, row_data in enumerate(table_data['rows'], start=1):  
            for col_idx, cell_data in enumerate(row_data):  
                cell = table.cell(row_idx, col_idx)  
                cell.text = str(cell_data)  # Convert data to string in case it's not  
                # You can add additional formatting for the row cell here  
                self.set_font_properties(cell, font_size=Pt(12))  
                logging.info(f"Adding cell: {cell_data}")
                for paragraph in cell.text_frame.paragraphs:  
                    paragraph.alignment = PP_ALIGN.CENTER  
  
  
      
    def add_chart_slide(self, title, chart_data):  
        slide_layout = self.prs.slide_layouts[5]  # Using layout 5 which is usually blank  
        slide = self.prs.slides.add_slide(slide_layout)  
        slide.shapes.title.text = title  
        
        # Define chart data  
        chart_type = chart_data['type']  
        data = chart_data['data']  
        categories = chart_data['categories']  
        series_names = chart_data['series_names']  
        
        # Create chart  
        x, y, cx, cy = Inches(2), Inches(1.5), Inches(6), Inches(4.5)  
        chart = slide.shapes.add_chart(  
            chart_type, x, y, cx, cy, chart_data['chart_data']  
        ).chart  
        
        # Set chart title  
        chart.has_title = True  
        chart.chart_title.text_frame.text = chart_data['chart_title']  
        
        # Set categories and series data  
        chart_data = chart.chart_data  
        for category in categories:  
            chart_data.categories.add(category)  
        for series_name, values in zip(series_names, data):  
            series = chart_data.add_series(series_name)  
            series.values = values  
      
    def add_footer(self, slide, text):  
        left = Inches(0)  
        top = Inches(7.5)  
        width = self.prs.slide_width  
        height = Inches(0.5)  
        txBox = slide.shapes.add_textbox(left, top, width, height)  
        tf = txBox.text_frame  
        p = tf.paragraphs[0]  
        run = p.add_run()  
        run.text = text  
        font = run.font  
        font.size = Pt(10)  
        font.color.rgb = RGBColor(255, 255, 255)  
      
    def create_presentation(self, slides_data_json):  
        for slide_data in slides_data_json['slides']:  
            title = slide_data['SlideTitle']  
            content = slide_data['SlideContent']  
            content_format = slide_data['SlideContentFormat']  
            logging.info(f"Creating slide with title: {title} and content format: {content_format}")  
            if content_format == 'Text':  
                slide = self.add_text_slide(title, content)  
            elif content_format == 'Table':  
                slide = self.add_table_slide(title, content)  
            elif content_format == 'Chart':  
                slide = self.add_chart_slide(title, content)  
              
           
      
    def save_presentation(self, output_path):  
        self.prs.save(output_path)  

    def save_presentation(self, prs_bytes: BytesIO):  
        self.prs.save(prs_bytes)  
        
  
