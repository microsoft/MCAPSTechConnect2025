from askai_core.data_insight import CosmosDBDataProcessor

class AskAIAgentManager:
        
    # Define required keys as global variables
    REQUIRED_KEYS = [
        "id",
        "module", 
        "class", 
        "AgentName", 
        "AgentDescription", 
        "service_url", 
        "authentication", 
        "request_template", 
        "required_fields"
    ]

    AUTH_REQUIRED_KEYS = ["type", "key_vault_secret_name"]
    TEMPLATE_REQUIRED_KEYS = ["QueryType", "Query", "Language"]

    def __init__(self, cosmos_db_processor : CosmosDBDataProcessor=None):
        self.cosmos_db_processor = cosmos_db_processor

    @classmethod
    async def load(cls, cosmos_db_processor :CosmosDBDataProcessor=None):
           return cls(cosmos_db_processor=cosmos_db_processor)
        
    async def update_agent(self, agent_id, content):
        try:
            await self.cosmos_db_processor.update_document_content(item_id=agent_id, partition_key=agent_id, updated_content=content)
            return (f"Successfully updated content of agent file {agent_id}")
        except ValueError as e:
            raise ValueError(f"Error updating agent file {agent_id}: {str(e)}")
    
    async def create_agent(self, agent_id, content):
            try:
                await self.cosmos_db_processor.create_document(item_id=agent_id, content=content)
                return (f"Successfully created agent file {agent_id}")
            except ValueError as e:
                raise ValueError(f"Error creating agent file {agent_id}: {str(e)}")

    async def get_agent(self, file_name):
        try:
            prompt_item = await self.cosmos_db_processor.read_document(item_id=file_name, partition_key=file_name)
            return prompt_item.get('content')
        except ValueError as e:
            raise ValueError(f"Error fetching prompt file {file_name} from Cosmos DB: {str(e)}")
                
    async def validate_agent_data(self,agentData):
        # Check top-level required keys
        for key in self.REQUIRED_KEYS:
            if not agentData[key]:
                return False,f"Blank value for key: {key}"

        # Check authentication required keys
        authentication = agentData["authentication"]
        for key in self.AUTH_REQUIRED_KEYS:
            if key not in authentication:
                return False,f"Missing key in authentication: {key}"
            if not authentication[key]:
                return False, f"Blank value for key in authentication: {key}"

        # Check request_template required keys
        request_template = agentData["request_template"]
        for index, template in enumerate(request_template):
            for key in self.TEMPLATE_REQUIRED_KEYS:
                if key not in template:
                    return False, f"Missing key in request_template at index {index}: {key}"
                if not template[key]:
                    return False, f"Blank value for k"

        return True, "All required keys are present and not blank"