import base64
import datetime
from msgraph import GraphServiceClient
from msgraph.generated.models.subscription import Subscription

class sharepoint_utils:
    async def get_graph_file_content_from_sharepoint(self, graph_client: GraphServiceClient, drive_id, item_id) -> bytes:
        """
        Use the Graph client to download the file content from SharePoint

        Args:
            drive_id (str): drive_id of the SharePoint site
            item_id (str): item_id of the file

        Raises:
            Exception: If the file download fails for any reason

        Returns:
            str: Raw content from graph api
        """
        try:
            response = await graph_client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).content.get()

            if len(response) > 200:
                return response
            else:
                raise Exception(f"Failed to download file. Status code: {response.status_code}")
        except Exception as e:
            print(f"An error occurred while downloading the file : {str(e)}")
            return None  
        
    # Generate a random secret key once for all the subscriptions created by the bot to verify the signature of the incoming notifications
    def generate_secret_key(self, secret_key):
        """
        Generate a secret key for the subscription using base64 encoding algorithm to verify the signature of the incoming notifications

        Args:
            secret_key (str): secret key used to sign the notification

        Returns:
            str: base64 encoded secret key used to sign the notification
        """
        return base64.urlsafe_b64encode(secret_key).decode('utf-8')
    
    def verify_signature(self, signature, secret_key):
        """
        Verify the signature of the incoming notification using hmac & sha256 algorithm
        
        Args:
            signature (str): Signature of the incoming notification
            secret_key (str): Secret key used to sign the notification
        
        Returns:
            bool: True if the signature is valid, False otherwise
        """        
        # Compute the expected signature
        expected_signature = self.generate_secret_key(secret_key)
        
        # Compare the expected signature with the received signature
        return signature == expected_signature
    
    def generate_expiration_datetime(self, minutes=42300) -> str:
        """
        Generate the expiration datetime for the subscription

        Args:
            minutes (int, optional): Defaults to 42300.

        Returns:
            datetime: Expiration datetime for the subscription
        """
        expiry = (datetime.datetime.now() + datetime.timedelta(minutes=minutes)).isoformat() + 'Z'
        return expiry
    
    async def get_all_subscriptions(self, graph_client: GraphServiceClient):
        """
        Get all the subscriptions created by the bot

        Returns:
            list: List of all the subscriptions created by the bot
        """
        return await graph_client.subscriptions.get()
    
    async def get_site_id(self, site_url, graph_client: GraphServiceClient):
        """
        G
        """
        # Get the site information using the site URL
        site = await graph_client.sites.by_site_id(site_url)

        return site['id']
    
    async def get_drives(self, site_id, graph_client: GraphServiceClient):
        # Get the drive (document library) information for the given site
        drives = await graph_client.drives.get()

        return drives.value
    
    async def get_drive_id_by_name(self, site_id, drive_name, graph_client: GraphServiceClient):
        # Get the drive (document library) information for the given site
        drives = await graph_client.sites.by_site_id(site_id).drives.get()

        for drive in drives.value:
            if drive.name == drive_name:
                return drive.id
    
    # Function to create subscription
    async def create_subscription(self, graph_client: GraphServiceClient, site_id, drive_id, notification_url, secret_key, minutes=42000) -> Subscription:
        """
        Create a subscription for the list items in the SharePoint site

        Args:
            drive_id (str): drive_id of the SharePoint list
            notification_url (str): URL to receive the notifications
            secret_key (str): secret key to use for client state

        Returns:
            Subscription: Subscription response from the graph api
        """
        request_body = Subscription (
            change_type = 'updated',
            notification_url = notification_url,
            resource = f'/sites/{site_id}/drives/{drive_id}/root',
            expiration_date_time = self.generate_expiration_datetime(minutes),
            client_state = secret_key
        )
        
        return await graph_client.subscriptions.post(request_body)
    
    # Function to update a subscription
    async def update_subscription(self, graph_client: GraphServiceClient, subscription_id, notification_url = None, minutes=42000) -> Subscription:
        """
        Update the subscription with the new notification URL and expiration datetime

        Args:
            subscription_id (str): subscription id to update
            notification_url (str): URL to receive the notifications

        Returns:
            Subscription: Subscription response from the graph api
        """
        request_body = Subscription(
            expiration_date_time = self.generate_expiration_datetime(minutes),
        )
        if notification_url is not None:
            request_body.notification_url = notification_url
            
        return await graph_client.subscriptions.by_subscription_id(subscription_id).patch(request_body)
    
    # Function to delete a subscription
    async def delete_subscription(self, graph_client: GraphServiceClient, subscription_id):
        """
        Delete the subscription using the subscription id

        Args:
            subscription_id (str): subscription id to delete

        Returns:
            Subscription: Subscription response from the graph api
        """
        return await graph_client.subscriptions.by_subscription_id(subscription_id).delete()
        