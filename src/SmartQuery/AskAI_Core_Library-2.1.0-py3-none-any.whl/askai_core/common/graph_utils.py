from typing import Union
from msgraph import GraphServiceClient
from azure.core.credentials import TokenCredential
from azure.core.credentials_async import AsyncTokenCredential

class graph_utils:    
    async def get_graph_client(self, credential: Union[TokenCredential, AsyncTokenCredential], scopes, use_private_endpoint = False, base_url = None) -> GraphServiceClient:
        """
        Initialize the Graph client for private network
        
        Args:
            scopes (str): https://graph.microsoft.com/.default
            use_private_endpoint (bool): Only use this flag if you are connecting to a private endpoint
            base_url (str): Base URL for the private endpoint
            
        Returns:
            GraphServiceClient: Graph client object
        """
        if use_private_endpoint:
            return GraphServiceClient(credential, scopes, base_url)
        else:
            return GraphServiceClient(credential, scopes)
        
    async def get_access_token(self, credential: Union[TokenCredential, AsyncTokenCredential], scopes):
        """
        Function to get access token using Managed Identity with token lifetime details -
        https://learn.microsoft.com/en-us/graph/api/resources/subscription?view=graph-rest-1.0#subscription-lifetime

        Args:
            credential (DefaultAzureCredential): Use the DefaultAzureCredential class to authenticate the client using managed identity
            scopes (str): https://graph.microsoft.com/.default

        Returns:
            str: token
        """
        token = await credential.get_token(scopes)
        return token.token
    
    async def get_all_subscriptions(self, graph_client: GraphServiceClient):
        """
        Get all the subscriptions created by the bot

        Returns:
            List[Subscription]: List of subscriptions created by the bot
        """
        return await graph_client.subscriptions.get()
    
    async def get_subscription_by_id(self, graph_client: GraphServiceClient, subscription_id):
        """
        Get the subscription using the subscription id

        Args:
            subscription_id (str): subscription id to get

        Returns:
            Subscription: Subscription response from the graph api
        """
        return await graph_client.subscriptions.by_subscription_id(subscription_id).get()
        