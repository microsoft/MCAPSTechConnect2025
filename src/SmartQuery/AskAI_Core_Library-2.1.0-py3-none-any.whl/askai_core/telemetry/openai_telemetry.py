
from datetime import datetime, timezone
import logging
import uuid
from askai_core.Utility.functions import count_tokens_str, track_execution_time
from askai_core.telemetry import CosmosUtility


@track_execution_time
class OpenAiTelemetry:
    """
    A class that provides functionality for saving telemetry into Cosmos db.
    """
    def __init__(self, cosmos_endpoint:str, cosmos_key:str, cosmos_database_name:str, cosmos_container_name:str):
        self.cosmos_endpoint = cosmos_endpoint
        self.cosmos_key = cosmos_key
        self.cosmos_database_name = cosmos_database_name
        self.cosmos_container_name = cosmos_container_name
        if self.cosmos_endpoint and self.cosmos_database_name and self.cosmos_container_name:
          self.cosmos_utility = CosmosUtility(self.cosmos_endpoint, self.cosmos_key, self.cosmos_database_name, self.cosmos_container_name)

    async def capture_telemetry_data(self, ai_assistant, conversation_id, prompt, response, start_time, end_time, model, response_tokens):
        try:
            logging.info(f"Capturing telemetry data for conversation_id {conversation_id}")
            if conversation_id!='NA' or conversation_id!='' or conversation_id!=None or self.cosmos_endpoint!=None or self.cosmos_endpoint!="":
                # Calculate the time difference
                time_difference = end_time - start_time            
                # Extract hours, minutes, and seconds from the time difference
                hours, remainder = divmod(time_difference.total_seconds(), 3600)
                minutes, seconds = divmod(remainder, 60)
                # Format the result as a string
                time_taken = "{:02}:{:02}:{:02}".format(int(hours), int(minutes), int(seconds))

                # Generaate Guid for id field       
                uu_id = uuid.uuid4()

                # Extract user and system prompts
                system_content, user_content = self.extract_prompt_contents(prompt)

                # Count Tokens
                prompt_tokens = count_tokens_str(system_content, model)
                request_tokens = count_tokens_str(user_content, model)
                
                data_to_insert = {
                    "id": str(uu_id),
                    "Category": "OpenAI",
                    "AiAssistant": ai_assistant,
                    "AssistantStartTimestamp": self.convert_to_utc_iso(start_time),
                    "AssistantEndTimestamp": self.convert_to_utc_iso(end_time),
                    "Feedback": 0,
                    "ConversationId": conversation_id,
                    "MessageStartTimestamp": " ",
                    "MessageEndTimestamp": " ",
                    "Prompt": system_content,
                    "PromptTokens": prompt_tokens,
                    "Request": user_content,
                    "RequestTokens": request_tokens,
                    "Response": response,
                    "ResponseTokens": response_tokens,
                    "TotalTokens": prompt_tokens + request_tokens + response_tokens,
                    "Latency": time_taken,
                    "SessionId": " ",
                    "SessionStartTimestamp": " ",
                    "SessionEndTimestamp": " "
                }

                self.cosmos_utility.create_item(data_to_insert)
                logging.info(f"Open AI Telemetry recorded")

        except Exception as e:
            logging.error(f"Error capturing telemetry data: {str(e)}")

    def extract_prompt_contents(self, prompt):
        system_content  = ""
        user_content = ""
        for item in prompt:
            if item['role'] == 'system':
                system_content = item['content']
            elif item['role'] == 'user':
                user_content = item['content']
        return system_content, user_content
    
    def convert_to_utc_iso(self, dt):
        # Convert it to UTC
        dt = dt.astimezone(timezone.utc)
        # Convert it to ISO 8601 format
        iso_format = dt.isoformat()
        return iso_format
       