import logging
from azure.cosmos import CosmosClient, exceptions

class CosmosDBDataProcessor:
    def __init__(self, endpoint, key, database_name, container_name, connection_pool_size=10):
        self.endpoint = endpoint
        self.key = key
        self.database_name = database_name
        self.container_name = container_name
        self.connection_pool_size = connection_pool_size
        self.client = None
        self.logger = logging

    async def __aenter__(self):
        try:
            self.client = CosmosClient(self.endpoint, self.key)
            self.logger.info("Connected to Cosmos DB")
            return self
        except Exception as e:
            self.logger.error(f"Error connecting to Cosmos DB: {e}")
            raise RuntimeError(f"Error connecting to Cosmos DB: {e}")

    async def __aexit__(self, exc_type, exc_value, traceback):
        if self.client:
            self.logger.info("Closing Cosmos DB client")

    async def get_container_client(self):
        try:
            database = self.client.get_database_client(self.database_name)
            container = database.get_container_client(self.container_name)
            return container
        
        except exceptions as e:
            self.logger.error(f"Error getting container client: {e}")
            raise RuntimeError(f"Error getting container client: {e}")

    async def query_documents(self, query, parameters=None):
        try:
            container = await self.get_container_client()
            items = list(container.query_items(query, parameters=parameters))
            return items
        except exceptions as e:
            self.logger.error(f"Error executing query: {e}")
            raise ValueError(f"Error executing query: {e}")

    async def insert_document(self, document):
        try:
            container = await self.get_container_client()
            container.upsert_item(document)
            self.logger.info("Document inserted successfully")
        except exceptions as e:
            self.logger.error(f"Error inserting document: {e}")
            raise ValueError(f"Error inserting document: {e}")
