from typing import Generator, Tuple
from askai_core.content_parser import BaseParser

class PPTXParser(BaseParser):
    def extract_text(self) ->  Generator[Tuple[int, str, bool], None, None]:
        is_image_present = False
        content_bytes = self.file_content
        document_analysis_client = self.documentAnalysisClient
        poller = document_analysis_client.begin_analyze_document("prebuilt-read", content_bytes)
        result = poller.result()
        number_of_pages = len(result.pages)

        for index in range(number_of_pages):
            current_page = result.pages[index]
            page_number = index + 1
            page_content = ""

            for word in current_page.words:
                if word.content:
                    page_content += word.content + " "

            yield page_number, page_content.strip(), is_image_present  # Strip trailing whitespace